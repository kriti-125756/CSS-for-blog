A Pen created at CodePen.io. You can find this one at https://codepen.io/Creaticode/pen/ecAmo.

 Como hacer un menú despegable estilo acordeón con jQuery. How to make an accordion menu with jQuery no Plugins.
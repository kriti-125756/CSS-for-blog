A Pen created at CodePen.io. You can find this one at https://codepen.io/andytran/pen/eIgoJ.

 A simple flat vertical navigation with multi animated drop down menu.  Also including Font Awesome and Animate.css